//
//  NewsTableViewController.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "NewsTableViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "News.h"
#import "NewsTableViewCell.h"
#import "FocusImgView.h"
#import "FocusImgManager.h"
#import "NewsDetailTableViewController.h"
#import "DataParsed.h"
#import "MJRefresh.h"
#import "DetailNewController.h"
#import "FocusImg.h"

@interface NewsTableViewController ()<FocusimgViewDelegate>


@property(nonatomic,strong) DataParsed * dataParsed;
@property(nonatomic,strong) NSMutableArray * dataArray;
@property(nonatomic,assign) BOOL isload;

@end

@implementation NewsTableViewController
//页面即将出现
- (void)viewWillAppear:(BOOL)animated{
    self.tabBarController.tabBar.hidden = NO;
}
//实现轮播代理方法
- (void)focusimgViewDidCarousel:(FocusimgView *)focusimgView atIndex:(NSInteger)index{
    NewsDetailTableViewController * newsDTVC = [[NewsDetailTableViewController alloc]init];
    FocusImg *img = [FocusImgManager sharedManager].array[index];
    newsDTVC.ID = img.Id;
    [self.navigationController pushViewController:newsDTVC animated:YES];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.isload = NO;
    //调用block刷新UI（轮播）
    [FocusImgManager sharedManager].myData = ^(){
        FocusImgView *focusimgView = [[FocusImgView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height/3.0)];
        focusimgView.delegate = self;
        self.tableView.tableHeaderView = focusimgView;
        [self.tableView reloadData];
    };
    

    [self data];
    [self setupRefresh];
    
}
//上拉加载下来刷新
-(void)setupRefresh{
    self.tableView.mj_header = [MJRefreshNormalHeader    headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    [self.tableView.mj_header beginRefreshing];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    [self.tableView.mj_footer beginRefreshing];

    
}
//下拉刷新
- (void)loadNewData{
    self.isload = NO;
    NSString * loadNewUrl = @"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt1-p1-s30-l0.json";
    [self.dataParsed dataParesWithURL:loadNewUrl];
        [self.tableView.mj_header endRefreshing];
    
}
//上拉加载
-(void)loadMoreData{
    self.isload = YES;
    NSString * loadMoreUrl = [NSString stringWithFormat:@"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt1-p2-s30-l%@.json",[self.dataArray lastObject][@"lasttime"]];
    [self.dataParsed dataParesWithURL:loadMoreUrl];
       [self.tableView.mj_footer endRefreshing];
    
}


//解析方法
-(void)data{
    NSString * newsURL = @"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt1-p1-s30-l0.json";
    [self.dataParsed dataParesWithURL:newsURL];
    __weak typeof(self)weakSelf = self;
    self.dataParsed.mydata = ^(NSDictionary *dic){
        if (weakSelf.isload) {
            [weakSelf.dataArray addObjectsFromArray:dic[@"newslist"]];
        }else{
            [weakSelf.dataArray removeAllObjects];
            weakSelf.dataArray = [NSMutableArray arrayWithArray:dic[@"newslist"]];
        }
        [weakSelf.tableView reloadData];
    };
    
    
}
#pragma mark  lazyload
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return _dataArray.count;
    
}
//cell点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailNewController * newsDetailVC = [[DetailNewController alloc]initWithNibName:@"DetailNewController" bundle:nil];
    News * news = [News NewsWithDictionary:_dataArray[indexPath.row]];
    newsDetailVC.ID = (int)news.Id;
//    newsDetailVC.titleName = @"新闻";
    [self.navigationController pushViewController:newsDetailVC animated:YES];
    
    
}
//cell设置
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NewsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newCell" forIndexPath:indexPath];
    News * news = [News NewsWithDictionary:_dataArray[indexPath.row]];
    cell.news = news;
        NSLog(@"~~!~~%@",news);
    
    return cell;
}
#pragma mark  --  lazyload
-(DataParsed *)dataParsed{
    if (!_dataParsed) {
        _dataParsed = [DataParsed new];
    }
    return _dataParsed;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
