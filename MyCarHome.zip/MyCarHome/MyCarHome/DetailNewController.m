//
//  DetailNewController.m
//  HomeForCar
//
//  Created by lanou3g on 15/11/21.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import "DetailNewController.h"
#import "NewsTableViewCell.h"
#import "NewsDetail.h"
#import "CommentsListController.h"
#import "DataParsed.h"
#import "News.h"
#import "NewsDetailTableViewCell.h"

@interface DetailNewController ()<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UIButton *btn4Comments;
- (IBAction)acrtion4seeComments:(UIButton *)sender;


@property (nonatomic, strong) NSDictionary *dataDic;
@property (nonatomic, strong) DataParsed * dataPares;
@property (nonatomic, strong) News *news;
@end

@implementation DetailNewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.tabBar.hidden = YES;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"收藏" style:(UIBarButtonItemStylePlain) target:self action:@selector(collectClick:)];
    // 代理和数据源
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    // 注册
    [self.myTableView registerNib:[UINib nibWithNibName:@"NewsDetailTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"newsDetailCell"];

    // 解析数据
    NSString *url = [NSString stringWithFormat:@"http://cont.app.autohome.com.cn/autov5.0.0/content/news/newsinfo-pm2-i%d.json", self.ID];
    self.dataPares = [DataParsed new];
    [self.dataPares dataParesWithURL:url];
    __weak typeof(self)weakSelf = self;
    self.dataPares.mydata = ^(NSDictionary *dic){
        weakSelf.dataDic = [NSDictionary dictionaryWithDictionary:dic];
        [weakSelf.btn4Comments setTitle:[NSString stringWithFormat:@"%@评", weakSelf.dataDic[@"replycount"]] forState:UIControlStateNormal];
        [weakSelf.myTableView reloadData];
    };
}

- (void)collectClick:(UIBarButtonItem *)sender{
    NSLog(@"收藏");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark TableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self textHeight:self.dataDic[@"description"]] + 348;
}

// 计算字符串的frame
- (CGFloat)textHeight: (NSString *)string{
    CGRect rect = [string boundingRectWithSize:CGSizeMake(365, 10000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]} context:nil];
    // 返回计算好的高度
    return rect.size.height;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NewsDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newsDetailCell" forIndexPath:indexPath];
    cell.newsDetail = [NewsDetail detailNewsModelWithDictionary:self.dataDic];
    return cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)acrtion4seeComments:(UIButton *)sender {
    CommentsListController *commentList = [[CommentsListController alloc] initWithNibName:@"CommentsListController" bundle:nil];
    commentList.newsID = self.ID;
    [self.navigationController pushViewController:commentList animated:YES];
}


@end
