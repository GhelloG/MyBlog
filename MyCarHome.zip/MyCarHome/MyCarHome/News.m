//
//  News.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "News.h"

@implementation News

//容错处理
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
    if ([key isEqualToString:@"id"]) {
        _Id = (int)value;
    }
    
}
//初始化
-(instancetype)initWithDictionary:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
    
    
}
//类方法便利构造器
+(instancetype)NewsWithDictionary:(NSDictionary *)dic{
    News * news = [[News alloc]initWithDictionary:dic];
    
    return news;
}

-(NSString *)description{
    
    return [NSString stringWithFormat:@"%@",_title];
}

@end
