//
//  NewsDetailTableViewController.h
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsDetailTableViewController : UITableViewController

@property(nonatomic,assign) NSInteger ID;

@property(nonatomic,strong) NSString * titleName;

@end
