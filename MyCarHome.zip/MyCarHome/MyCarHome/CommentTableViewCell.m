//
//  CommentTableViewCell.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "CommentTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation CommentTableViewCell

-(void)setComment:(Comment *)comment{
    _titleLabel.text = comment.title;
    _timeLabel.text = comment.time;
    _replycountLabel.text = [NSString stringWithFormat:@"%ld 评论",comment.replycount];
    [_carsImg sd_setImageWithURL:[NSURL URLWithString:comment.smallpic]];
    _titleLabel.numberOfLines = 0;
    
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
