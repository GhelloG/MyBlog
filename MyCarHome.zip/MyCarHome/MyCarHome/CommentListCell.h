//
//  CommentListCell.h
//  HomeForCar
//
//  Created by lanou3g on 15/11/21.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentModel.h"

@interface CommentListCell : UITableViewCell

@property (nonatomic, strong) CommentModel *commentModel;
@property (strong, nonatomic) IBOutlet UILabel *lab4Content;
@property (strong, nonatomic) IBOutlet UILabel *lab4SourceContent;
@end
