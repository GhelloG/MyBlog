//
//  CommentTableViewCell.h
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Comment.h"
@interface CommentTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *carsImg;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *timeLabel;
@property (strong, nonatomic) IBOutlet UILabel *replycountLabel;

@property(nonatomic,strong) Comment * comment;

@end
