//
//  FocusImgManager.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "FocusImgManager.h"
#import "AFHTTPRequestOperationManager.h"
#import "FocusImg.h"
@interface FocusImgManager ()

@property(nonatomic,strong) NSDictionary * dict;
//@property(nonatomic,strong) NSMutableArray * array;

@end


static FocusImgManager * manager = nil;
@implementation FocusImgManager

+(FocusImgManager *)sharedManager{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
            manager = [FocusImgManager new];
            [manager dataparse];
    });
    
    return manager;
    
}

-(void)dataparse{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
       NSString * focusImgURL = @"http://app.api.autohome.com.cn/autov4.2/news/newslist-a2-pm1-v4.2.0-c0-nt0-p1-s30-l0.html";
        AFHTTPRequestOperationManager * manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        __weak typeof (self)temp = self;
        [manager GET:focusImgURL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            if (responseObject) {
                _dict = [NSMutableDictionary dictionary];
                _dict = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingAllowFragments) error:nil][@"result"];
               NSArray * arr = _dict[@"focusimg"];
                for (NSDictionary * dic in arr) {
                    FocusImg * focusModel = [FocusImg focusImgWithDictionary:dic];
                    [temp.array addObject:focusModel];
                }
            }
            //返回主线程更新UI
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!self.myData) {
                    NSLog(@"没有数据");
                }else{
                    self.myData();
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"%@",error);
            _dict = nil;
            
        }];
    });
    
    
}
- (NSArray *)allFocusimg{
    return self.array;
}

- (NSMutableArray *)array{
    if (!_array) {
        _array = [NSMutableArray arrayWithCapacity:10];
    }
    return _array;
}

@end
