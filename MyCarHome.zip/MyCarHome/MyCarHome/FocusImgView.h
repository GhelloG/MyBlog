//
//  FocusImgView.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FocusimgView;
//设置代理
@protocol FocusimgViewDelegate <NSObject>
//生命代理方法
- (void)focusimgViewDidCarousel:(FocusimgView *)focusimgView atIndex:(NSInteger)index;

@end


@interface FocusImgView : UIView
//代理属性
@property(nonatomic,strong) id<FocusimgViewDelegate>delegate;

@end
