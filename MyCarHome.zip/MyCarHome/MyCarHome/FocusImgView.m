//
//  FocusImgView.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "FocusImgView.h"
#import "FocusImgManager.h"
#import "FocusImg.h"
#import "UIImageView+WebCache.h"
@interface FocusImgView ()<UIScrollViewDelegate>

@property(nonatomic,strong) UIScrollView * scrollView;
@property(nonatomic,strong) UIPageControl * pageCon;
@property(nonatomic,strong) NSTimer * timer;
@property(nonatomic,assign) NSInteger currentIndex;
@property(nonatomic,assign) NSTimeInterval duration;

@end
@implementation FocusImgView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        _timer = [NSTimer new];
        _duration = 2;
        [self buildUI];
    }
    return self;
}
//构建UI
-(void)buildUI{
    [self.timer invalidate];
    self.timer = nil;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:self.duration target:self selector:@selector(carouselFromTimer:) userInfo:nil repeats:YES];
    [self addSubview:self.scrollView];
    [self addSubview:self.pageCon];
    
    
}
//timer驱动轮播
-(void)carouselFromTimer:(id)sender{
    self.currentIndex ++;
    if (self.currentIndex == [FocusImgManager sharedManager].array.count) {
        self.currentIndex = 0;
    }
    self.pageCon.currentPage = self.currentIndex;
    [self.scrollView setContentOffset:CGPointMake(self.frame.size.width * self.currentIndex, 0)];
    
}
-(UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.frame];
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.bounces = NO;
        _scrollView.delegate = self;
        
        _scrollView.contentSize = CGSizeMake(self.frame.size.width * [FocusImgManager sharedManager].allFocusImg.count, self.frame.size.height);
        for (int i = 0; i < [FocusImgManager sharedManager].array.count; i++) {
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.width * i, 0, self.frame.size.width, self.frame.size.height)];
            FocusImg *model = [FocusImgManager sharedManager].array[i];
            NSLog(@"~~~~!%lu", [FocusImgManager sharedManager].array.count);
            NSLog(@"````!%@", model);
            [imgView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
            imgView.userInteractionEnabled = YES;
            imgView.tag = 1000 + i;
            // 添加手势
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
            [imgView addGestureRecognizer:tap];
            
            [_scrollView addSubview:imgView];
        }
    }
    return _scrollView;
}
// tap手势
- (void)tapAction:(UITapGestureRecognizer *)tap{
    NSInteger index = tap.view.tag - 1000;
    if (_delegate && [_delegate respondsToSelector:@selector(focusimgViewDidCarousel:atIndex:)]) {
        [_delegate focusimgViewDidCarousel:self atIndex:index];
         }
}


-(UIPageControl *) pageCon{
    if (!_pageCon) {
        self.pageCon = [[UIPageControl alloc] initWithFrame:CGRectMake(self.frame.size.width/3.0, self.frame.size.height - 30, 150, 30)];
        _pageCon.numberOfPages = [FocusImgManager sharedManager].array.count;
        _pageCon.pageIndicatorTintColor = [UIColor darkGrayColor];
        _pageCon.currentPageIndicatorTintColor = [UIColor whiteColor];
        
    }

    return _pageCon;
}
// scrollView代理方法
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    // 开始拖动时，timer停止
    [self.timer invalidate];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    self.timer = nil;
    self.pageCon.currentPage = self.scrollView.contentOffset.x/self.frame.size.width;
    self.currentIndex = self.pageCon.currentPage;
    // 启动timer
    self.timer = [NSTimer scheduledTimerWithTimeInterval:self.duration target:self selector:@selector(carouselFromTimer:) userInfo:nil repeats:YES];
}
// 赋值
- (void)setDuration:(NSTimeInterval)duration{
    [self.timer invalidate];
    self.timer = nil;
    _duration = duration;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:self.duration target:self selector:@selector(carouselFromTimer:) userInfo:nil repeats:YES];
}


@end
