//
//  ActivityTableViewCell.h
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Activity.h"

@interface ActivityTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *carImage;
@property (weak, nonatomic) IBOutlet UILabel *titleLb;
@property (weak, nonatomic) IBOutlet UILabel *beginTimeLb;
@property (weak, nonatomic) IBOutlet UILabel *pcviewsLb;
@property (weak, nonatomic) IBOutlet UILabel *endTimeLb;
@property (weak, nonatomic) IBOutlet UILabel *cityLb;

@property(nonatomic,strong) Activity * acti;

@end
