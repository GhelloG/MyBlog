
//
//  ActivityData.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/17.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "ActivityData.h"
#import "AFHTTPRequestOperationManager.h"
#import "ActivityTableViewController.h"

@interface ActivityData ()



@end

@implementation ActivityData

static ActivityData * manager = nil;
+(ActivityData *)sharedManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [ActivityData new];
        [manager dataParse];
    });
    return manager;
}

-(void)dataParse{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
       NSString * activityURL = @"http://app.api.autohome.com.cn/autov5.0.0/mobile/activitylist-pm1-c210100-b0-ss0-p1-s20.json";
        AFHTTPRequestOperationManager * manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager GET:activityURL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            _dataDic = [NSMutableDictionary dictionary];
            _dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingAllowFragments) error:nil][@"result"];
           //返回主线程更新UI
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!self.myData) {
                    NSLog(@"没有数据");
                }else{
                    self.myData();
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"%@",error);
            _dataDic = nil;
        }];
        
    });
    
    
}



@end
