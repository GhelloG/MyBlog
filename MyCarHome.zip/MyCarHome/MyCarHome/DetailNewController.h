//
//  DetailNewController.h
//  HomeForCar
//
//  Created by lanou3g on 15/11/21.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailNewController : UIViewController

@property (nonatomic, assign) int ID; // 接收传过来的位置
@end
