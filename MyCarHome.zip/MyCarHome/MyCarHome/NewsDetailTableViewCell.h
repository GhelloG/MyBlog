//
//  NewsDetailTableViewCell.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/19.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsDetail.h"
@interface NewsDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *carsImg;
@property (weak, nonatomic) IBOutlet UILabel *describtionLabel;



@property(nonatomic,strong) NewsDetail * newsDetail;
@end
