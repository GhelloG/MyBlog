//
//  FocusImgManager.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^parseData)();


@interface FocusImgManager : NSObject

@property(nonatomic,strong) NSArray * allFocusImg;
@property(nonatomic,copy) parseData  myData;
@property(nonatomic,strong) NSMutableArray * array;
//单例
+(FocusImgManager *)sharedManager;

@end
