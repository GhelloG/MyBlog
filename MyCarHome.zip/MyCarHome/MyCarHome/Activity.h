//
//  Activity.h
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Activity : NSObject

@property(nonatomic,strong) NSString * Id;
@property(nonatomic,strong) NSString * pubtime;//起始时间
@property(nonatomic,strong) NSString * regenddate;//结束时间
@property(nonatomic,strong) NSString * starttime;//活动开始时间
@property(nonatomic,strong) NSString * endtime;//活动结束时间
@property(nonatomic,strong) NSString * title;
@property(nonatomic,assign) NSInteger pcviews;//关注人数
@property(nonatomic,strong) NSString * AllValue;
@property(nonatomic,strong) NSString * imgpath;
@property(nonatomic,strong) NSString * address;
@property(nonatomic,strong) NSString * cityname;


-(instancetype)initWithDictionary:(NSDictionary *)dict;
+(instancetype)activityWithDictionary:(NSDictionary *)dict;


@end
