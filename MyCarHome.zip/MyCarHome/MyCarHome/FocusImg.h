//
//  FocusImg.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FocusImg : NSObject

@property(nonatomic,assign) NSInteger Id;
@property(nonatomic,strong) NSString * imgurl;
@property(nonatomic,strong) NSString * title;
@property(nonatomic,strong) NSString * type;

+(instancetype)focusImgWithDictionary:(NSDictionary *)dic;

@end
