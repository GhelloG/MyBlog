//
//  CommentTableViewController.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "CommentTableViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "Comment.h"
#import "CommentTableViewCell.h"
#import "NewsDetailTableViewController.h"
#import "DataParsed.h"
#import "MJRefresh.h"
#import "DetailNewController.h"
@interface CommentTableViewController ()

@property(nonatomic,strong) NSMutableArray * dataArray;
@property(nonatomic,assign) BOOL isload;
@property(nonatomic,strong) DataParsed * dataParsed;
@end

@implementation CommentTableViewController

-(void)viewWillAppear:(BOOL)animated{
    self.tabBarController.tabBar.hidden = NO;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self data];
    [self setupRefresh];
}
//刷新加载
-(void)setupRefresh{
    self.tableView.mj_header = [MJRefreshNormalHeader    headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    [self.tableView.mj_header beginRefreshing];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    [self.tableView.mj_footer beginRefreshing];
    
    
}
- (void)loadNewData{
    self.isload = NO;
    NSString * loadNewUrl = @"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt3-p2-s30-l0.json";
    [self.dataParsed dataParesWithURL:loadNewUrl];
    [self.tableView.mj_header endRefreshing];
    
}
-(void)loadMoreData{
    self.isload = YES;
    NSString * loadMoreUrl = [NSString stringWithFormat:@"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt3-p2-s30-l%@.json",[self.dataArray lastObject][@"lasttime"]];
    
    [self.dataParsed dataParesWithURL:loadMoreUrl];
    [self.tableView.mj_footer endRefreshing];
    
    
}

//解析
-(void)data{
    NSString * commentURL = @"http://app.api.autohome.com.cn/autov5.0.0/news/newslist-pm1-c0-nt3-p2-s30-l0.json";
    [self.dataParsed dataParesWithURL:commentURL];
    __weak typeof(self)weakSelf = self;
    self.dataParsed.mydata = ^(NSDictionary *dic){
        if (weakSelf.isload) {
            [weakSelf.dataArray addObjectsFromArray:dic[@"newslist"]];
        }else{
            [weakSelf.dataArray removeAllObjects];
            weakSelf.dataArray = [NSMutableArray arrayWithArray:dic[@"newslist"]];
        }
        [weakSelf.tableView reloadData];
    };
    
}

#pragma mark  --  lazyload
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    
    return _dataArray;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    NSLog(@"%ld",_dataArray.count);
    return _dataArray.count;
    
}
//cell点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailNewController * newsDetailVC = [[DetailNewController alloc]initWithNibName:@"DetailNewController" bundle:nil];
    Comment * comment = [Comment commentWithDictionary:_dataArray[indexPath.row]];
    newsDetailVC.ID = (int)comment.Id;
    NSLog(@"%ld~~~~~~~",(long)comment.Id);
//    newsDetailVC.titleName = @"评测";
    [self.navigationController pushViewController:newsDetailVC animated:YES];
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentCell" forIndexPath:indexPath];
    Comment * comment = [Comment commentWithDictionary:_dataArray[indexPath.row]];
    cell.comment = comment;
    
    return cell;
}
#pragma mark  --  lazyload
-(DataParsed *)dataParsed{
    if (!_dataParsed) {
        _dataParsed = [DataParsed new];
    }
    return _dataParsed;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
