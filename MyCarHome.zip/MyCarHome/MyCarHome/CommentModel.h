//
//  CommentModel.h
//  HomeForCar
//
//  Created by lanou3g on 15/11/22.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentModel : NSObject

@property (nonatomic, assign) int ID;
@property (nonatomic, strong) NSString *nameid;
@property (nonatomic, strong) NSString *name; // 评者名字
@property (nonatomic, strong) NSString *namepic; // 头像
@property (nonatomic, strong) NSString *time; //
@property (nonatomic, strong) NSString *content;
@property (nonatomic, assign) int sourcenameid;
@property (nonatomic, strong) NSString *sourcecontent;  // 原评论内容
@property (nonatomic, strong) NSString *carname;
@property (nonatomic, assign) int upcount; // 点赞
@property (nonatomic, assign) int floor;
@property (nonatomic, strong) NSString *sourcename;

+ (instancetype)commentModelWithDictionary:(NSDictionary *)dictionary;

@end
