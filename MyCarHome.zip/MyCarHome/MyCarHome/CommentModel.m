//
//  CommentModel.m
//  HomeForCar
//
//  Created by lanou3g on 15/11/22.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        _ID = (int)value;
    }
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    if ([super init]) {
        [self setValuesForKeysWithDictionary:dictionary];
    }
    return self;
}

+ (instancetype)commentModelWithDictionary:(NSDictionary *)dictionary{
    CommentModel *model = [[CommentModel alloc] initWithDictionary:dictionary];
    return model;
}

@end
