//
//  Comment.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "Comment.h"

@implementation Comment

//容错处理
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
    if ([key isEqualToString:@"id"]) {
        _Id = (int)value;
    }
    
}

-(instancetype)initWithDictionary:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
    
    
}
+(instancetype)commentWithDictionary:(NSDictionary *)dic{
    Comment * comment = [[Comment alloc]initWithDictionary:dic];
    
    return comment;
}

-(NSString *)description{
    
    return [NSString stringWithFormat:@"%@",_title];
}


@end
