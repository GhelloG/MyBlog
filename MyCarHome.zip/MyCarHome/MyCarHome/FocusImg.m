//
//  FocusImg.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/18.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "FocusImg.h"

@implementation FocusImg

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        _Id = (int)value;
    }
}
-(instancetype)initWithDictionary:(NSDictionary *)dic{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}
+(instancetype)focusImgWithDictionary:(NSDictionary *)dic{
    FocusImg * focusImg = [[FocusImg alloc]initWithDictionary:dic];
    return focusImg;
}


@end
