//
//  ActivityTableViewCell.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "ActivityTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation ActivityTableViewCell

-(void)setActi:(Activity *)acti{
    _titleLb.text = acti.title;
    _beginTimeLb.text = [NSString stringWithFormat:@"%@至",acti.pubtime ];
    _endTimeLb.text = acti.regenddate;
    _cityLb.text = acti.cityname;
    _pcviewsLb.text = [NSString stringWithFormat:@"%ld人关注",acti.pcviews];
    [_carImage sd_setImageWithURL:[NSURL URLWithString:acti.imgpath]];
    
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
