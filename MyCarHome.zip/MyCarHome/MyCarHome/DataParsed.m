//
//  DataParsed.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/20.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "DataParsed.h"
#import "AFHTTPRequestOperationManager.h"

@interface DataParsed ()

@property(nonatomic,strong)NSMutableDictionary * dataDic;

@end

@implementation DataParsed

-(void)dataParesWithURL:(NSString *)url{
    AFHTTPRequestOperationManager * manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    __weak typeof(self)weakSelf = self;
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (responseObject) {
            _dataDic = [NSMutableDictionary dictionary];
        _dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingAllowFragments) error:nil][@"result"];
            weakSelf.mydata(_dataDic);
        }
                
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        _dataDic = nil;
    }];
    
};



@end
