//
//  NewsDetail.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/19.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "NewsDetail.h"

@implementation NewsDetail

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        _Id = (int)value;
    }else if ([key isEqualToString:@"description"]){
        _descrip = value;
    }
    
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dictionary];
    }
    return self;
}

+ (instancetype)detailNewsModelWithDictionary:(NSDictionary *)dictionary{
    NewsDetail *detailNews = [[NewsDetail alloc] initWithDictionary:dictionary];
    return detailNews;
}


@end
