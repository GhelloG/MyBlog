//
//  DataParsed.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/20.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^dataPares)(NSDictionary *);
@interface DataParsed : NSObject

-(void)dataParesWithURL:(NSString *)url;

@property(nonatomic,strong) dataPares  mydata;

@end
