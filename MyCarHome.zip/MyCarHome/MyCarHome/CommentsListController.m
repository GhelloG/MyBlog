//
//  CommentsListController.m
//  HomeForCar
//
//  Created by lanou3g on 15/11/21.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import "CommentsListController.h"
#import "CommentListCell.h"
#import "Comment.h"
#import "DataParsed.h"

@interface CommentsListController ()<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
- (IBAction)action4AddAction:(UIButton *)sender;
@property (nonatomic, strong) DataParsed * dataPares;
@property (nonatomic, strong) NSMutableArray *hotlist;
@property (nonatomic, strong) NSMutableArray *list;
@end

@implementation CommentsListController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.tabBar.hidden = YES;
    // 注册自定义cell
    [self.myTableView registerNib:[UINib nibWithNibName:@"CommentListCell" bundle:nil] forCellReuseIdentifier:@"commentListCell"];
    self.myTableView.delegate = self;
    self.myTableView.dataSource =self;
    [self requestData];
}

- (void)requestData{
    self.dataPares = [DataParsed new];
    [self.dataPares dataParesWithURL:[NSString stringWithFormat:@"http://app.api.autohome.com.cn/autov5.0.5/news/comments-pm2-n%d-o0-s20-lastid0.json", self.newsID]];
    NSLog(@"%@",[NSString stringWithFormat:@"http://app.api.autohome.com.cn/autov5.0.5/news/comments-pm2-n%d-o0-s20-lastid0.json", self.newsID]);
    __weak typeof(self)weakSelf = self;
    self.dataPares.mydata = ^(NSDictionary *dic){
        weakSelf.hotlist = dic[@"hotlist"];
        weakSelf.list = dic[@"list"];
        [weakSelf.myTableView reloadData];
    };
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark -- TableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return self.hotlist.count;
    }else{
        return self.list.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (![self.hotlist[indexPath.row][@"sourcecontent"] length] == 0) {
            return [self textHeight:self.hotlist[indexPath.row][@"content"] andFontSize:15] + [self textHeight:self.hotlist[indexPath.row][@"sourcecontent"] andFontSize:14] + 120;
        }else{
            return [self textHeight:self.hotlist[indexPath.row][@"content"] andFontSize:15] + 100;
        }
    }else if (indexPath.section == 1) {
        if (![self.list[indexPath.row][@"sourcecontent"] length] == 0) {
            return [self textHeight:self.list[indexPath.row][@"content"] andFontSize:15] + [self textHeight:self.list[indexPath.row][@"sourcecontent"] andFontSize:14] + 120;
        }else{
            return [self textHeight:self.list[indexPath.row][@"content"] andFontSize:15] + 100;
        }
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"热门评论";
    }else{
        return @"最新评论";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CommentListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"commentListCell" forIndexPath:indexPath];
    if (indexPath.section == 0) {
        cell.commentModel = [CommentModel commentModelWithDictionary:self.hotlist[indexPath.row]];
    }else if (indexPath.section == 1){
        cell.commentModel = [CommentModel commentModelWithDictionary:self.list[indexPath.row]];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

// 计算字符串的frame
- (CGFloat)textHeight: (NSString *)string andFontSize:(int)size{
    CGRect rect = [string boundingRectWithSize:CGSizeMake(290, 10000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:size]} context:nil];
    // 返回计算好的高度
    return rect.size.height;
    
}

#pragma mark -- outletAction

- (IBAction)action4AddAction:(UIButton *)sender {
}



#pragma mark -- lazyload

- (NSMutableArray *)hotlist{
    if (!_hotlist) {
        _hotlist = [NSMutableArray arrayWithCapacity:10];
    }
    return _hotlist;
}

- (NSMutableArray *)list{
    if (!_list) {
        _list = [NSMutableArray arrayWithCapacity:10];
    }
    return _list;
}
@end
