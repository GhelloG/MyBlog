//
//  ActivityDetailTableViewCell.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/19.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "ActivityDetailTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation ActivityDetailTableViewCell

-(void)setActivity:(Activity *)activity{
    [_carsImg sd_setImageWithURL:[NSURL URLWithString:activity.imgpath]];
    _titleLabel.text = activity.title;
    _titleLabel.numberOfLines = 0;
    _addressLabel.text = [NSString stringWithFormat:@"活动地点：%@",activity.address];
    NSString * startTime = [activity.starttime substringToIndex:10];
    NSString * endTime = [activity.endtime substringToIndex:10];
    _timeLabel.text = [NSString stringWithFormat:@"活动时间：%@ 至 %@",startTime,endTime];
    _endTimeLabel.text = [NSString stringWithFormat:@"截止时间：%@",activity.regenddate];
    _allValueLabel.text = [NSString stringWithFormat:@"平均花销：%@元",activity.AllValue];
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
