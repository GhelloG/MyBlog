//
//  ActivityData.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/17.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^parseData)();

@interface ActivityData : NSObject

@property(nonatomic,copy) parseData  myData;
@property(nonatomic,strong) NSDictionary * dataDic;
//单例

+(ActivityData *)sharedManager;


@end
