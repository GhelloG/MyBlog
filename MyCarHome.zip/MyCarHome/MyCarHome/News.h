//
//  News.h
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface News : NSObject

@property(nonatomic,assign) NSInteger  Id;
@property(nonatomic,strong) NSString * title;
@property(nonatomic,strong) NSString * time;
@property(nonatomic,strong) NSString * smallpic;
@property(nonatomic,assign) NSInteger replycount;
@property(nonatomic,strong) NSString * lasttime;


-(instancetype)initWithDictionary:(NSDictionary *)dic;
+(instancetype)NewsWithDictionary:(NSDictionary *)dic;

@end
