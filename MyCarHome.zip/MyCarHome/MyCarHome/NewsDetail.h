//
//  NewsDetail.h
//  MyCarHome
//
//  Created by 果正达 on 15/11/19.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsDetail : NSObject

@property(nonatomic,strong) NSString * descrip;
@property(nonatomic,assign) NSInteger  Id;
@property(nonatomic,strong) NSString * title;
@property(nonatomic,strong) NSString * time;
@property(nonatomic,strong) NSString * img;
@property (nonatomic, assign) int replycount;

+ (instancetype)detailNewsModelWithDictionary:(NSDictionary *)dictionary;

@end
