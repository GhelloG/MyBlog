//
//  CommentListCell.m
//  HomeForCar
//
//  Created by lanou3g on 15/11/21.
//  Copyright © 2015年 zhangxiaoguang. All rights reserved.
//

#import "CommentListCell.h"
#import "UIImageView+WebCache.h"
@interface CommentListCell ()
@property (strong, nonatomic) IBOutlet UIImageView *img4Header;
@property (strong, nonatomic) IBOutlet UILabel *lab4Nmae;
@property (strong, nonatomic) IBOutlet UILabel *lab4CarName;
@property (strong, nonatomic) IBOutlet UILabel *lab4Time;
@property (strong, nonatomic) IBOutlet UIButton *btn4AddUp;
@property (strong, nonatomic) IBOutlet UILabel *lab4Floor;
@property (strong, nonatomic) IBOutlet UILabel *lab4ReplyCount;
- (IBAction)action4AddUp:(UIButton *)sender;
- (IBAction)action4Reply:(UIButton *)sender;

@end

@implementation CommentListCell

- (void)setCommentModel:(CommentModel *)commentModel{
    _commentModel = commentModel;
    _lab4Nmae.text = commentModel.name;
    _lab4CarName.text = commentModel.carname;
    _lab4Content.text = commentModel.content;
    _lab4Time.text = commentModel.time;
    _lab4Floor.text = [NSString stringWithFormat:@"%d楼", commentModel.floor];
    _lab4ReplyCount.text = [NSString stringWithFormat:@"%d", commentModel.upcount];
    if (![commentModel.sourcecontent isEqual:@""]) {
        _lab4SourceContent.text = [NSString stringWithFormat:@"原评论:%@\n%@",commentModel.sourcename,commentModel.sourcecontent];
    }else{
        _lab4SourceContent.text = nil;
    }
    if (commentModel.namepic) {
        [_img4Header sd_setImageWithURL:[NSURL URLWithString:commentModel.namepic] placeholderImage:[UIImage imageNamed:@"headerImg"]];
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)action4AddUp:(UIButton *)sender {
}

- (IBAction)action4Reply:(UIButton *)sender {
    [_lab4ReplyCount.text intValue];
}
@end
