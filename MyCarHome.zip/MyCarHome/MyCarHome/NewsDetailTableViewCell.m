//
//  NewsDetailTableViewCell.m
//  MyCarHome
//
//  Created by 果正达 on 15/11/19.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "NewsDetailTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation NewsDetailTableViewCell

-(void)setNewsDetail:(NewsDetail *)newsDetail{
    _titleLabel.text = newsDetail.title;
    _timeLabel.text = newsDetail.time;
    [_carsImg sd_setImageWithURL:[NSURL URLWithString:newsDetail.img]];
    _describtionLabel.text = newsDetail.descrip;
    _describtionLabel.numberOfLines = 0;
    
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
