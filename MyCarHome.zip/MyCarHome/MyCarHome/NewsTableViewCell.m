//
//  NewsTableViewCell.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "NewsTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation NewsTableViewCell

//赋值
-(void)setNews:(News *)news{
    _titleLabel.text = news.title;
    _timeLabel.text = news.time;
    _replycountLabel.text = [NSString stringWithFormat:@"%ld 评论",news.replycount];
    [_carImg sd_setImageWithURL:[NSURL URLWithString:news.smallpic]];
    _titleLabel.numberOfLines = 0;
    
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
