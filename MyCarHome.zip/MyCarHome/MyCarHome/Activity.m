//
//  Activity.m
//  MyCarHome
//
//  Created by lanou3g on 15/11/16.
//  Copyright © 2015年 guozhengda.com. All rights reserved.
//

#import "Activity.h"

@implementation Activity

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        _Id = value;
    }
    
}

-(instancetype)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dict];
    }
    
    return self;
    
}
+(instancetype)activityWithDictionary:(NSDictionary *)dict{
    
    Activity * act = [[Activity alloc]initWithDictionary:dict];
    
    return act;
}

-(NSString *)description{
    
    return [NSString stringWithFormat:@"%@",_title];
}

@end
